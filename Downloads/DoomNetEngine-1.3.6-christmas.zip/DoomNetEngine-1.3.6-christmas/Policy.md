**The DoomNet Policy**

1. No inappropriate content or images.
2. You will not post copyrighted-content.
3. Be friendly and nice on this repo.

Extra notes
Your search history on DoomNet will be recorded[^1].

**Consequences**
1. Deleting merge.
2. Closing pull requests.
3. A temporary ban.
4. Permanent ban

We aim to make DoomNet Engine a friendly site so please help us achieve it!

Thank you for your cooperation and have a nice day! :)