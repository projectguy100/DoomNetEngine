**This folder is for any deprecated features wich might be added later and basically a dump for old code and images for DoomNet.**
