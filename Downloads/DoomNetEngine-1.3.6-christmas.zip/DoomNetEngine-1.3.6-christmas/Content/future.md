This is a list of what might be added for the next update, approx release dates, features and some other notes of improvement.

**Next update [The Halloween update 1] -> 1.4.0**
- Improve icon (halloween icon) ✓✓✓
- Add a changelog link ✓✓✓
- Add more searches ✓✓✓
- Add feedback and add URL form - https://forms.gle/CeeCBtmhvBUeCHnK9 {scrapped for this update - moved to November update 1}
- indexing on google if searched 'doomnetengine', 'doomnet-engine' or etc ✓✓✓
- Downloadable content ✓✓✓
- Decry.txt ✓✓✓
- Halloween themed icons and banenners ✓✓✓

**Next update [The Halloween update 2] -> 1.3.2.5**
- Recry.txt ✓✓✓
- Downloads link to image ✓✓✓
- Change downloads link to bottom of page ✓✓✓
- Some bug fixes ✓✓✓

**Next update [The Halloween update 3] -> 1.3.3**
- Halloween day(30-31th October 2024) surprise!!! ✓✓✓
- Jumpscare ✘
- Update the changelog sites ✓✓✓
- log

**November Update [Firework update 1]**
**_Release date (approx may be not accurate): 10th November 2024 or earlier_**
- Fireworks ✘
- Nice animations ✘
- More js ✘
- Remove Halloween themes icons and stuff {Place in Contents/Archive folder} ✓✓✓
- Add feedback and add URL form - https://forms.gle/CeeCBtmhvBUeCHnK9 ✘

**Christmas Update [Update 1]**
- Christmas icons and banners ✓✓✓
- Add feedback and add URL form - https://forms.gle/CeeCBtmhvBUeCHnK9 
- More js
- Snowflakes - [IN PROGRESS]
- Christmas background music

**Notes**
- Add a 404 page ✓✓✓
- Make the main branch deploy as index.html ✓✓✓
- Buy a Domain [Unecessary To Buy] ✘
- Add sounds (Added 1 for Halloween) ✓
- Website builder for DoomNetEngine for future website requests to add {Scrapped may add in the future} ✘
